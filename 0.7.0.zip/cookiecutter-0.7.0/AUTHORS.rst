=======
Credits
=======

Development Lead
----------------

* Audrey Roy <audreyr@gmail.com>

Contributors
------------

* Daniel Greenfeld (`@pydanny`_)
* Steven Loria (`@sloria`_)
* Goran Peretin (`@gperetin`_)
* Hamish Downer (`@foobacca`_)
* Thomas Orozco (`@krallin`_)
* Jindrich Smitka (`@s-m-i-t-a`_)
* Benjamin Schwarze (`@benjixx`_)
* Raphi (`@raphigaziano`_)
* Thomas Chiroux (`@ThomasChiroux`_)
* Sergi Almacellas Abellana (`@pokoli`_)
* Alex Gaynor (`@alex`_)
* Rolo (`@rolo`_)
* Pablo (`@oubiga`_)

.. _`@audreyr`: https://github.com/audreyr
.. _`@pydanny`: https://github.com/pydanny
.. _`@sloria`: https://github.com/sloria
.. _`@gperetin`: https://github.com/gperetin
.. _`@foobacca`: https://github.com/foobacca
.. _`@krallin`: https://github.com/krallin
.. _`@s-m-i-t-a`: https://github.com/s-m-i-t-a
.. _`@benjixx`: https://github.com/benjixx
.. _`@raphigaziano`: https://github.com/raphigaziano
.. _`@ThomasChiroux`: https://github.com/ThomasChiroux
.. _`@pokoli`: https://github.com/pokoli
.. _`@alex`: https://github.com/alex
.. _`@rolo`: https://github.com/rolo
.. _`@oubiga`: https://github.com/oubiga
