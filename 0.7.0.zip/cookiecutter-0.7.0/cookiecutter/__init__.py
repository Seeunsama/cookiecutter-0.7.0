#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
cookiecutter
------------

Main package for Cookiecutter.
"""

__version__ = '0.7.0'
